-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: j5b306.p.ssafy.io    Database: b306
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts_customuser`
--

DROP TABLE IF EXISTS `accounts_customuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_customuser` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `email` varchar(254) NOT NULL,
  `nickname` varchar(45) NOT NULL,
  `total_score` int NOT NULL,
  `tier_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `accounts_customuser_tier_id_0905a392_fk_tier_codes_id` (`tier_id`),
  CONSTRAINT `accounts_customuser_tier_id_0905a392_fk_tier_codes_id` FOREIGN KEY (`tier_id`) REFERENCES `tier_codes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_customuser`
--

LOCK TABLES `accounts_customuser` WRITE;
/*!40000 ALTER TABLE `accounts_customuser` DISABLE KEYS */;
INSERT INTO `accounts_customuser` VALUES (50,'pbkdf2_sha256$260000$dcdUQyg88ic0Ty90mqYAjw$9LTKTgfmyUs32WURll93XOF4qtpoBY4xh61FhrhfGnM=',NULL,0,'','',0,1,'2021-10-07 13:16:18.055055','s1@naver.com','배포왕하태린',2020,1),(51,'pbkdf2_sha256$260000$aYM39JOWxnX8FXza7doCh1$o1Uc5zExzi2LteBSxsjP2Ik7rg257t0yl6dZb9lnjCQ=',NULL,0,'','',0,1,'2021-10-07 13:16:22.848233','asdf1@ssafy.com','노른계란자',1890,2),(52,'pbkdf2_sha256$260000$wxpRmTylr2Vjk0nkPJcVZC$ftca+VBy6vp9ZNg16f4zfL65NgENvVASihYy2PqrRek=',NULL,0,'','',0,1,'2021-10-07 13:16:52.756456','s2@naver.com','시무룩',1790,2),(53,'pbkdf2_sha256$260000$4M2V0ukk961I1AvrboBeiI$96SnWR8OWYwPHAJo1WQiAphhBONXc9ydDA7oYhpNE00=',NULL,0,'','',0,1,'2021-10-07 13:17:12.542286','s3@naver.com','나는싸피인이다',1030,3),(54,'pbkdf2_sha256$260000$72BL2FpTBsz6Y6HG34J4wB$DvnOnJUE8SF23vqIh4zgGg/cyXWnMmxtIYiEq5vg8UI=',NULL,0,'','',0,1,'2021-10-07 13:17:32.380054','asdf2@ssafy.com','지하3층6호',570,4),(55,'pbkdf2_sha256$260000$dY6xLw1MwCCeY1XALx9Cib$XReg203e2oW8aZskCMGLPg+rsb+Vg62V+UnigdDbES8=',NULL,0,'','',0,1,'2021-10-07 13:17:40.030647','s4@gmail.com','재밌는지문자',390,5),(56,'pbkdf2_sha256$260000$uwW0jY3sxDabnxz2S3vGtN$sF2JuXKRLKwtnPCtzoX4xBwk81Iyz4EppCOo5zCJk80=',NULL,0,'','',0,1,'2021-10-07 13:18:15.914075','s5@naver.com','나랑악수할래?',210,5),(57,'pbkdf2_sha256$260000$J08LwdGYA91gYhSSvSQ2dm$9Qoyzrr6Kz7nWPwPpTdjNPV4Rlc3q64WzNIu8NvifQs=',NULL,0,'','',0,1,'2021-10-07 13:18:37.046819','s6@naver.com','취뽀하자',1550,2),(58,'pbkdf2_sha256$260000$4Lcb0xLVeuKsdK51NwFFLn$OFXIhMSidjZdBqOf4iMWp5mAZxt//Rz16VPG5SHkRzk=',NULL,0,'','',0,1,'2021-10-07 13:18:47.753660','junho1@ssafy.com','빠커센세',670,4),(59,'pbkdf2_sha256$260000$ZXDMkkY3fFGNUsp5s9gsPn$fIOaxrwuNfA8jnsE3RH/8HOOHGyl5wCBI3fG71bdV3c=',NULL,0,'','',0,1,'2021-10-07 13:43:50.004972','test2@gma.com','지문자 좋아',0,5),(60,'pbkdf2_sha256$260000$HNKwTGAmqb49UuPfqXAbam$UEdYcUEGR1Lk7/HzXkjXPC+17MK4AaAQu73kcw/LAGw=',NULL,0,'','',0,1,'2021-10-07 13:54:32.139717','asdf@ssafy.com','안녕하세요!',0,5),(61,'pbkdf2_sha256$260000$x82VDUuMcFMBrUfpxZWlaw$3L1gPljr7YuwhmiqEB2NcYC02lzWewGyGURJ7JFrkU0=',NULL,0,'','',0,1,'2021-10-07 14:22:47.648607','asdf2341@ssafy.com','안녕하세요@!@',0,5),(62,'pbkdf2_sha256$260000$itVZIocF14CKwr2DKxrMBW$QFodsUIvo0pGaUv3rbdmf/NK/LHlK36zVeXok9HNIy8=',NULL,0,'','',0,1,'2021-10-07 18:15:30.043976','s4@naver.com','자고싶어요',0,5),(63,'pbkdf2_sha256$260000$K9GAJTF9QweIQqHlsXScyP$EHg/vl+3g70/82z/20NGIAqzdg/c+qBQklAOGxSQXaw=',NULL,0,'','',0,1,'2021-10-07 18:16:32.197232','aasdf1@asdf.com','된다!',0,5);
/*!40000 ALTER TABLE `accounts_customuser` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-08  4:49:54
