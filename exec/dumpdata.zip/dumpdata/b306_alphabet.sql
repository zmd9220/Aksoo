-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: j5b306.p.ssafy.io    Database: b306
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alphabet`
--

DROP TABLE IF EXISTS `alphabet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alphabet` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '아이디',
  `image_url` varchar(100) DEFAULT NULL COMMENT '지문자사진',
  `mean` varchar(45) DEFAULT NULL COMMENT '의미',
  `type_id` int DEFAULT NULL COMMENT '지문자타입아이디',
  PRIMARY KEY (`id`),
  KEY `FK_alphabet_type_id_alphabet_type_code_id` (`type_id`),
  CONSTRAINT `FK_alphabet_type_id_alphabet_type_code_id` FOREIGN KEY (`type_id`) REFERENCES `alphabet_type_code` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='지문자';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alphabet`
--

LOCK TABLES `alphabet` WRITE;
/*!40000 ALTER TABLE `alphabet` DISABLE KEYS */;
INSERT INTO `alphabet` VALUES (1,'letters/ㄱ.jpg','ㄱ',1),(2,'letters/ㄴ.jpg','ㄴ',1),(3,'letters/ㄷ.jpg','ㄷ',1),(4,'letters/ㄹ.jpg','ㄹ',1),(5,'letters/ㅁ.jpg','ㅁ',1),(6,'letters/ㅂ.jpg','ㅂ',1),(7,'letters/ㅅ.jpg','ㅅ',1),(8,'letters/ㅇ.jpg','ㅇ',1),(9,'letters/ㅈ.jpg','ㅈ',1),(10,'letters/ㅊ.jpg','ㅊ',1),(11,'letters/ㅋ.jpg','ㅋ',1),(12,'letters/ㅌ.jpg','ㅌ',1),(13,'letters/ㅍ.jpg','ㅍ',1),(14,'letters/ㅎ.jpg','ㅎ',1),(20,'letters/ㅏ.jpg','ㅏ',2),(21,'letters/ㅑ.jpg','ㅑ',2),(22,'letters/ㅓ.jpg','ㅓ',2),(23,'letters/ㅕ.jpg','ㅕ',2),(24,'letters/ㅗ.jpg','ㅗ',2),(25,'letters/ㅛ.jpg','ㅛ',2),(26,'letters/ㅜ.jpg','ㅜ',2),(27,'letters/ㅠ.jpg','ㅠ',2),(28,'letters/ㅡ.jpg','ㅡ',2),(29,'letters/ㅣ.jpg','ㅣ',2);
/*!40000 ALTER TABLE `alphabet` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-08  4:49:58
